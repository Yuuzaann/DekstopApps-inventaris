package config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Administrator
 */
public class Koneksi {
    private static Connection conn;

    // Ubah sesuai konfigurasi database kamu
    private static final String URL = "jdbc:mysql://localhost:3306/inventorilab";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            try {
                Class.forName("com.mysql.jdbc.Driver"); // driver MySQL
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Koneksi database berhasil!");
            } catch (ClassNotFoundException | SQLException e) {
                System.err.println("Koneksi database gagal: " + e.getMessage());
                throw new SQLException("Tidak bisa konek ke database", e);
            }
        }
        return conn;
    }
}
