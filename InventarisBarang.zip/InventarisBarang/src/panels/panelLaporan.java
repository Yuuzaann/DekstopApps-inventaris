package panels;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import javax.swing.*;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;



public class panelLaporan extends javax.swing.JPanel {

    private Connection conn;

    private JPanel panelFilter;
    private JPanel panelViewer;

    private JComboBox<String> cmbRuang;
    private JButton btnCetak;
    private JButton btnPdf;

     // ===== CONSTRUCTOR =====
    public panelLaporan() {
        initKoneksi();
        initUI();
        loadComboRuang();
        initEvent();
    }
    
    // ===== KONEKSI DATABASE =====
    private void initKoneksi() {
        try {
            conn = config.Koneksi.getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Koneksi database gagal:\n" + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    // ===== SETUP UI =====
    private void initUI() {
        setLayout(new BorderLayout());

        // PANEL FILTER (ATAS)
        panelFilter = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelFilter.setOpaque(false);

        JLabel lblRuang = new JLabel("Kode Ruang:");
        cmbRuang = new JComboBox<>();
        btnCetak = new JButton("Cetak");
        btnPdf = new JButton("Export PDF");

        btnCetak.setEnabled(false);
        btnPdf.setEnabled(false);

        panelFilter.add(lblRuang);
        panelFilter.add(cmbRuang);
        panelFilter.add(btnCetak);
        panelFilter.add(btnPdf);

        // PANEL VIEWER (TENGAH)
        panelViewer = new JPanel(new BorderLayout());
        panelViewer.setOpaque(false);

        add(panelFilter, BorderLayout.NORTH);
        add(panelViewer, BorderLayout.CENTER);
    }
     // ===== LOAD DATA COMBO =====
    private void loadComboRuang() {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT id_ruang FROM ruang");

            cmbRuang.removeAllItems();
            cmbRuang.addItem("-- Pilih Kode Ruang --");

            while (rs.next()) {
                cmbRuang.addItem(rs.getString("id_ruang"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  
    // ===== EVENT HANDLER =====
    private void initEvent() {

        cmbRuang.addActionListener(e -> {
            boolean aktif = cmbRuang.getSelectedIndex() > 0;
            btnCetak.setEnabled(aktif);
            btnPdf.setEnabled(aktif);
        });

        btnCetak.addActionListener(e -> tampilkanLaporan());
        btnPdf.addActionListener(e -> exportPdf());
    }

    
    // ===== TAMPILKAN LAPORAN =====
    private void tampilkanLaporan() {
        try {
            if (cmbRuang.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this,
                    "Silakan pilih Kode Ruang terlebih dahulu!",
                    "Peringatan",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            panelViewer.removeAll();

            InputStream reportStream =
                getClass().getResourceAsStream("/laporan/lapRuang.jasper");

            if (reportStream == null) {
                JOptionPane.showMessageDialog(this,
                    "File laporan tidak ditemukan!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            HashMap<String, Object> param = new HashMap<>();
            param.put("id_ruang", cmbRuang.getSelectedItem().toString());

            JasperPrint print =
                JasperFillManager.fillReport(reportStream, param, conn);

            JRViewer viewer = new JRViewer(print);

            panelViewer.add(viewer, BorderLayout.CENTER);
            panelViewer.revalidate();
            panelViewer.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Gagal menampilkan laporan:\n" + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    // ===== EXPORT PDF =====
    private void exportPdf() {
        try {
            InputStream reportStream =
                getClass().getResourceAsStream("/laporan/lapRuang.jasper");

            if (reportStream == null) {
                JOptionPane.showMessageDialog(this,
                    "File laporan tidak ditemukan!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }

            HashMap<String, Object> param = new HashMap<>();
            param.put("id_ruang", cmbRuang.getSelectedItem().toString());

            JasperPrint print =
                JasperFillManager.fillReport(reportStream, param, conn);

            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File(
                "Laporan_Ruang_" + cmbRuang.getSelectedItem() + ".pdf"
            ));

            if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                JasperExportManager.exportReportToPdfFile(
                    print,
                    chooser.getSelectedFile().getAbsolutePath()
                );

                JOptionPane.showMessageDialog(this,
                    "PDF berhasil disimpan!",
                    "Sukses",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Gagal export PDF:\n" + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        ImageIcon img = new ImageIcon(getClass().getResource("/image/background4.jpg"));
        g.drawImage(img.getImage(), 0, 0, getWidth(), getHeight(), this);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
